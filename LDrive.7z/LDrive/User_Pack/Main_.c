#include "usbd_cdc_if.h"
#include "stdbool.h"
#include "Main.h"
#include "Motor_Control.h"
#include "tim.h"
#include "Foc.h"
#include "Encoder.h"
#include "Adc_Sample.h"
#include "Pid.h"

float vofa_trans[32];
uint8_t vofa_trans_[132];

_Noreturn void Main() {
    HAL_Delay(3000);
    Motor_Init();
    Motor_Calibrate();
    while (true) {
        HAL_GPIO_TogglePin(led0_GPIO_Port,led0_Pin);
        HAL_Delay(300);
        HAL_GPIO_TogglePin(led1_GPIO_Port,led1_Pin);
        HAL_Delay(300);
        HAL_GPIO_TogglePin(led2_GPIO_Port,led2_Pin);
        HAL_Delay(300);
    }
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
    if (&htim->Instance == &Timer_gate_drive.Instance) {
        Encoder_Get_Angle_analog(&Motor.Encoder_Theta_analog);
        Adc_Get_Current_Vbus(Motor.Abc_Current, Motor.Abc_Offstes, &foc.Udc);
        foc_Clark(Motor.Abc_Current[0], Motor.Abc_Current[2], Motor.Abc_Current[1], &Motor.AlphaBete_Current[0],
                  &Motor.AlphaBete_Current[1]);
        foc_Park(Motor.AlphaBete_Current[0], Motor.AlphaBete_Current[1], foc.Theta, &Motor.Qd_Current[0],
                 &Motor.Qd_Current[1]);
        Motor_Measure_Velocity(Motor.Encoder_Theta_analog, &Motor.Cur_Vel, &Motor.Cur_Pos);
        if (Motor.Motor_is_Calibrate) {
            Encoder_Get_Rle_Angle(Motor.Encoder_Theta_analog, &foc.Theta); //������������ֵ��ת��Ϊ��Ƕ�
            switch (Motor.Control_Mode) {
                case Control_Mode_Pos: {
                    Pid_Position(Motor.Tar_Pos, Motor.Cur_Pos, &Motor.Tar_Vel);
                    Pid_Velocity(Motor.Tar_Vel, Motor.Cur_Vel, &Motor.Tar_Qd_Current[0]);
                    Pid_Current(Motor.Tar_Qd_Current[0], 0, Motor.Qd_Current[0], Motor.Qd_Current[1], &foc.Vq, &foc.Vd);
                }
                    break;

                case Control_Mode_Vel: {
                    static uint8_t cal_cnt=0;
                    cal_cnt++;
                    if(Motor.control_hz==cal_cnt)
                    {
                        cal_cnt=0;
                        Pid_Velocity(Motor.Tar_Vel, Motor.Cur_Vel, &Motor.Tar_Qd_Current[0]);
                    }
                    Pid_Current(Motor.Tar_Qd_Current[0], 0, Motor.Qd_Current[0], Motor.Qd_Current[1], &foc.Vq, &foc.Vd);
                }
                    break;

                case Control_Mode_Cur: {
                    Pid_Current(Motor.Tar_Qd_Current[0], 0, Motor.Qd_Current[0], Motor.Qd_Current[1], &foc.Vq, &foc.Vd);
                }
                    break;

                case Control_Mode_Null: {

                }
                    break;
            }
            foc.Vq =0.09f;
            foc.Vd = 0.0f;
//            foc.Theta += 0.0010f;
        }

            if(Motor.Motor_is_protect) {
                HAL_TIM_PWM_Stop(&Timer_gate_drive, TIM_CHANNEL_1);
                HAL_TIM_PWM_Stop(&Timer_gate_drive, TIM_CHANNEL_2);
                HAL_TIM_PWM_Stop(&Timer_gate_drive, TIM_CHANNEL_3);
                HAL_TIM_PWM_Stop(&Timer_gate_drive, TIM_CHANNEL_4);
                HAL_TIMEx_PWMN_Stop(&Timer_gate_drive,  TIM_CHANNEL_1);
                HAL_TIMEx_PWMN_Stop(&Timer_gate_drive,TIM_CHANNEL_2);
                HAL_TIMEx_PWMN_Stop(&Timer_gate_drive, TIM_CHANNEL_3);
            }
            else{
                foc_Revpark(foc.Vq, foc.Vd, foc.Theta, &foc.Valpha, &foc.Vbeta);
                svpwm(foc.Valpha, foc.Vbeta, foc.Udc, foc.CCRs);
                foc_SetCCR(foc.CCRs);
            }
            ///ͼ����ʾ����
            vofa_trans[0] = foc.CCRs[0];
            vofa_trans[1] = foc.CCRs[1];
            vofa_trans[2] = foc.CCRs[2];

            vofa_trans[3] = Motor.Abc_Current[0];
            vofa_trans[4] = Motor.Abc_Current[1];
            vofa_trans[5] = Motor.Abc_Current[2];

            vofa_trans[6] = Motor.Tar_Qd_Current[0];
            vofa_trans[7] = Motor.Qd_Current[0];
            vofa_trans[8] = Motor.Tar_Qd_Current[1];
            vofa_trans[9] = Motor.Qd_Current[1];

            vofa_trans[10] = Motor.Tar_Vel;
            vofa_trans[11] = Motor.Cur_Vel;

            vofa_trans[12] = Pid.Pos_proportion;
            vofa_trans[13] = Pid.Pos_intergration;
            vofa_trans[14] = Pid.Pos_differential;

            vofa_trans[15] = Pid.Cur_proportion_q;
            vofa_trans[16] = Pid.Cur_intergration_q;

            vofa_trans[17] = foc.Vq;
            vofa_trans[18] = Motor.Encoder_Theta_analog;

            vofa_trans[19] = foc.Theta;

            vofa_trans[20] = Motor.Qd_Current[0];
            vofa_trans[21] = Motor.Qd_Current[1];

            vofa_trans[22] = Motor.Tar_Pos;
            vofa_trans[23] = Motor.Cur_Pos;
            vofa_trans[24] = Motor.Abc_Offstes[2];
            vofa_trans[25] = Motor.Encoder_Offset_Spi;
            vofa_trans[26] = Motor.Motor_is_protect;
            vofa_trans[27] = Pid.Cur_Ki;
            vofa_trans[28] = Motor.Control_Mode;
            vofa_trans[29] = foc.Valpha;
            vofa_trans[30] = foc.Vbeta;
            vofa_trans[31] = Motor.Motor_is_Calibrate;

            memcpy(vofa_trans_, (uint8_t *) vofa_trans, sizeof(vofa_trans));
            vofa_trans_[128] = 0X00;
            vofa_trans_[129] = 0X00;
            vofa_trans_[130] = 0X80;
            vofa_trans_[131] = 0X7F;
            CDC_Transmit_FS((uint8_t *) (vofa_trans_), 132);
        }
}

void Pack(uint8_t *buf) {                  ///usb���ƣ�����
    uint32_t state;
    float num, kp = 0, ki = 0, kd;
    sscanf((const char *) buf, "%ld,%f,%f,%f,%f", &state, &num, &kp, &ki, &kd);
    Motor.Control_Mode=state;
    Motor.Tar_Pos= num;
    Pid.Pos_Kp = kp;
    Pid.Pos_Ki = ki;
    Pid.Pos_Kd = kd;
}